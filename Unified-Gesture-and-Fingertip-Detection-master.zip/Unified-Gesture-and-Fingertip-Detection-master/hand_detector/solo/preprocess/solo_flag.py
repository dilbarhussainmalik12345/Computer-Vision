class Flag:
    def __init__(self):
        self.grid = 13
        self.grid_size = 32
        self.target_size = 416
        self.threshold = 0.5
