class Flag:
    def __init__(self):
        self.grid = 7
        self.grid_size = 32
        self.target_size = 224
        self.threshold = 0.5
        self.alpha = 0.5
        self.line_color = (18, 203, 227)
        self.grid_color = (81, 189, 42)
        self.box_color = (235, 26, 158)
