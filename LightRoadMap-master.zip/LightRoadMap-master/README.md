# LightRoadMap
If having advice or issue, please contact me at email  niu_wengang@163.com .   

## 1.Pipeline 

## 2.Prerequisites
Ubuntu20
Ros noetic


## 3. Compile 

## 4. Dataset

## 5. Run

## 6. Experimentation



## 7.Update Log

|date| branch | update  description | commit_id | video |
| :----: | :----:| :----: | :----:  | :----:  |
| 2022//11/20 | V0.1 | simple framework for mapping and localization  with  gnss、imu and lidar loosely coupled |6885639|[v0.1 demo1](https://www.bilibili.com/video/BV1mt4y1K7Nt/?spm_id_from=333.999.0.0&vd_source=b86740d9f2b244ac781ad5f60dd8e818)     [v0.1 demo2](https://www.bilibili.com/video/BV1Ce4y1s75g/?spm_id_from=333.788&vd_source=b86740d9f2b244ac781ad5f60dd8e818)|






## 8. Reference

[1]  [gaoxiang:slam_in_autonomous_driving](https://github.com/gaoxiang12/slam_in_autonomous_driving)  
[2]  [How to submit standard git commit？](https://zhuanlan.zhihu.com/p/182553920)   
[3] [AVP-SLAM-PLUS](https://github.com/liuguitao/AVP-SLAM-PLUS) 

## 9. Licence
The source code is released under [GPLv3](http://www.gnu.org/licenses/) license. 
