#ifndef _PUB_BASE_HPP
#define _PUB_BASE_HPP

namespace pub
{
class PubBase
{
  public:
    PubBase()
    {
    }
    // virtual PubMsg()
    virtual ~PubBase(){};
};
} // namespace pub

#endif //_PUB_BASE_HPP
