#ifndef _CLOUD_PUB_HPP
#define _CLOUD_PUB_HPP

#include "pub_base.hpp"

namespace pub
{
class CloudPub : public PubBase
{
};
} // namespace pub

#endif //_CLOUD_PUB_HPP