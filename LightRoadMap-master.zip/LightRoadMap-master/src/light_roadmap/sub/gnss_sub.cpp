#include "gnss_sub.hpp"

namespace sub
{
GnssSub::GnssSub()
{
}

void GnssSub::ParseData()
{
}
void GnssSub::MsgCallback()
{
}

bool GnssSub::HasSubscribed()
{
    return true;
}
GnssSub::~GnssSub()
{
}
} // namespace sub
