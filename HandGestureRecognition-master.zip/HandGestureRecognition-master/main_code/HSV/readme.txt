This MATLAB code generates 1000-dim HSV histogram for an input image, and perform global search using rootHSV.

Notes:
1) The number of bins for H, S, and V is 20, 10, 5, respectively.
