https://stackoverflow.com/questions/69993071/attributeerror-module-cv2-cv2-has-no-attribute-surf-create-2-module-cv2

pip install opencv-python==3.4.2.16
pip install opencv-contrib-python==3.4.2.16


install python 3.68 
https://www.python.org/downloads/release/python-368/

python36 -m venv pyenv36
pyenv36/Scripts/activate 