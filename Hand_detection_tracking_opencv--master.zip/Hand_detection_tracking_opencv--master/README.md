<h2>Hand_detection_tracking_opencv</h2>
<p>Recognizing gestures of hand and controlling the mouse. Use the hand_detection.py file to detect your hand and hand_detection_tracking.py to control mouse with your palm.</p>

<b>NOTE: Change the bgr value range according to your skin color, provide a range i.e. skin color appears different when exposed to different amount of light</b>

<h3>Demonstration show below</h3>
<img src = "https://github.com/globefire/Hand_detection_tracking_opencv-/blob/master/ezgif-4-1135f6c536.gif" width=400 height=230>

### Support Me
If you liked this Repository, then please leave a star on this repository. It motivates me to contribute more in such Open Source projects in the future.
### Happy Coding =)
