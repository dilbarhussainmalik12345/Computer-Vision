python train.py  --name day2night \
                 --dataset_loadtxt_A /path/to/domain_A_txt \
                 --dataset_loadtxt_B /path/to/domain_B_txt \
                 --gpu_ids 6 \
                 --loadimg_height 295 \
                 --loadimg_width 820 \

